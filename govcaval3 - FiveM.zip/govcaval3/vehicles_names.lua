Citizen.CreateThread(function()

    AddTextEntry("GOVCAVAL3", "Cavalcade XL Gov")
    AddTextEntry("UMKCAVAL3", "Cavalcade XL Unmarked")

end)